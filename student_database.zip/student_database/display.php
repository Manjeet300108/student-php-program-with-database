<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student</title>
    <?php include('./comman.php') ?>
</head>

<body>
    <div class="container">
        <button class="btn btn-primary my-5 "><a class="text-light" href="index.php">Add student</a></button>
        <table class="table">
            <thead>
                <tr class="table-warning">
                    <th scope="col">id</th>
                    <th scope="col">Student Name</th>
                    <th scope="col">Student Email</th>
                    <th scope="col">Student Password</th>
                    <th scope="col">Student Mobile No.</th>
                    <th scope="col">Student City</th>
                    <th scope="col">Opertaions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include('./connect.php');
                $sql = "SELECT * FROM `students`";
                $result = mysqli_query($conn, $sql);
                
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $name = $row['name'];
                        $email = $row['email'];
                        $password = $row['password'];
                        $mobile = $row['mobile'];
                        $city = $row['city'];
                        echo '<tr>
                        <th scope="row" >' . $id . '</th>
                        <td>' . $name . '</td>
                        <td>' . $email . '</td>
                        <td>' . $password . '</td>
                        <td>' . $mobile . '</td>
                        <td>' . $city . '</td>
                        <td>
                        <button class="btn btn-success" ><a class="text-light" href="./update.php?updateid='.$id.'">Update</a></button>
                        <button class= "btn btn-danger"><a class="text-light" href=" ./delete.php?deleteid='.$id.' ">Delete</a></button>
                        </td>
                        </tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>