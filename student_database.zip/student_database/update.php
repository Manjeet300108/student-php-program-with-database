<?php

include './connect.php';
$id = $_GET['updateid'];
$sql = "SELECT * FROM `students` WHERE id=$id";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row){
    $name = $row['name'];
    $email = $row['email'];
    $password = $row['password'];
    $mobile = $row['mobile'];
    $city = $row['city'];
}else{
    die (mysqli_error($conn));
}

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $mobile = $_POST['mobile'];
    $city = $_POST['city'];
    
    $sql = "UPDATE `students` SET id=$id,name='$name',email='$email',password='$password',mobile='$mobile',city='$city'
    WHERE id=$id";

    $result = mysqli_query($conn,$sql);
    if($result){
        header('location:display.php');
    }else{
        die(mysqli_error($conn));
    }
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student</title>
    <?php include('./comman.php')?>
</head>

<body>

    <form method="post">
        <div class="my-5 container">
            <div class="mb-3">
                <label>Student name</label>
                <input type="text" class="form-control" name="name" placeholder="Enter student name"
                    value=<?php echo $name?>>
                <br>

                <label>Student Email</label>
                <input type=" email" class="form-control" name="email" placeholder="Enter student email"
                    value=<?php echo $email?>><br>

                <label>Student Password</label>
                <input type="text" class="form-control" name="password" placeholder="Enter student Password"
                    value=<?php echo $password?>><br>

                <label>Student Mobile Number</label>
                <input type="text" class="form-control" name="mobile" placeholder="Enter student Mobile Number"
                    value=<?php echo $mobile?>><br>

                <label>Student City</label>
                <input type="text" class="form-control" name="city" placeholder="Enter student City"
                    value=<?php echo $city?>><br>
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
    </form>
</body>

</html>