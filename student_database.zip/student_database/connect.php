<?php

$conn = new mysqli('localhost','root','','school');

if(!$conn){
    die(mysqli_error($conn));
}
?>