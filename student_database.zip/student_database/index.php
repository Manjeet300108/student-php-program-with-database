<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student</title>
    <?php include('./comman.php')?>
</head>

<body>
    <h2 class="my-5 container"> STUDENT ADDMISSION FORM </h2>

    <form method="post">
        <div class="my-5 container">
            <div class="mb-3">
                <label>Student name</label>
                <input type="text" class="form-control" name="name" placeholder="Enter student name"><br>
                <label>Student Email</label>
                <input type="email" class="form-control" name="email" placeholder="Enter student email"><br>

                <label>Student Password</label>
                <input type="password" class="form-control" name="password" placeholder="Enter student Password"><br>

                <label>Student Mobile Number</label>
                <input type="text" class="form-control" name="mobile" placeholder="Enter student Mobile Number"><br>

                <label>Student City</label>
                <input type="text" class="form-control" name="city" placeholder="Enter student City"><br>
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
    </form>
</body>

</html>


<?php

include './connect.php';
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $mobile = $_POST['mobile'];
    $city = $_POST['city'];
    
    $sql = "INSERT INTO `students` (name,email,password,mobile,city)
    VALUES('$name','$email','$password','$mobile','$city')";

    $result = mysqli_query($conn,$sql);
    if($result){
        header('location:display.php');
    }else{
        die(mysqli_error($conn));
    }
}

?>